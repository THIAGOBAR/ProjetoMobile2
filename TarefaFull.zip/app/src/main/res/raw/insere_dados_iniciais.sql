INSERT INTO tarefa_tipo (id, nome) VALUES (1, 'Estudo');
INSERT INTO tarefa_tipo (id, nome) VALUES (2, 'Trabalho');
INSERT INTO tarefa_tipo (id, nome) VALUES (3, 'Casa');
INSERT INTO tarefa_tipo (id, nome) VALUES (4, 'Lazer');
INSERT INTO tarefa_tipo (id, nome) VALUES (5, 'Saúde');
INSERT INTO tarefa_tipo (id, nome) VALUES (6, 'Financeiro');